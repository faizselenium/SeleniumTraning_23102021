package OrangeHRM_Dema.OrangeHRM_Dema;


public class Test {

	@org.junit.Test
	public void test() {
		System.out.println("Hi");
	}

}
